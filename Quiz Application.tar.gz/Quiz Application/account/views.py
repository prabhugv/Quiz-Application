from django.shortcuts import render

# Create your views here.

from django.shortcuts import render

from account.forms import accountform

from django.http import HttpResponseRedirect

from account.models import account
from django.http import HttpResponse



def accountview(request):

    if request.method == 'POST':

        form = accountform(request.POST)

        if form.is_valid():

            name = request.POST.get('name')
            password = request.POST.get('password')
            confirm_password = request.POST.get('confirm_password')
            email = request.POST.get('email')
            phone_no = request.POST.get('phone_no')

            name_obj = account(name=name,password=password,confirm_password=confirm_password,email=email,phone_no=phone_no)

            name_obj.save()

            return HttpResponse("Register Successfull")

    else:

        form = accountform()

    return render(request,'account/account.html',{'form':form,})


