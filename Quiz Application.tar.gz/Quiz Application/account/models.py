from __future__ import unicode_literals

from django.db import models

# Create your models here.

class account(models.Model):
	name = models.CharField(max_length=10)
	password = models.CharField(max_length=10,null=True)
	confirm_password = models.CharField(max_length=10,null=True)
	email = models.EmailField(null=True)
	phone_no = models.TextField(null=True)
	login_status = models.BooleanField(default=False)
	
	
