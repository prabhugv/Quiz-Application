from django import forms
from .models import account
from django.forms import ModelForm

class accountform(forms.Form):
	name = forms.CharField()
	password = forms.CharField()
	confirm_password = forms.CharField()
	email = forms.EmailField()
	phone_no = forms.IntegerField()
	
class Meta:
    model = account
    fields = '__all__'
