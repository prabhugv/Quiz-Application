from django.conf.urls import url
from . import views

app_name = 'quiz'

urlpatterns = [
					url(r'^start/$',views.QuizListView.as_view(), name='quiz_index'),
					
					url(r'^category/$',views.CategoriesListView.as_view(),name='quiz_category_list_all'),

					url(r'^category/(?P<category_name>[\w.-]+)/$', views.ViewQuizListByCategory.as_view(),name='quiz_category_list_matching'),

					url(r'^progress/$', views.QuizUserProgressView.as_view(), name='quiz_progress'),

					url(r'^marking/$', views.QuizMarkingList.as_view(),name='quiz_marking'),

					url(r'^marking/(?P<pk>[\d.]+)/$', views.QuizMarkingDetail.as_view(), name='quiz_marking_detail'),

					#  passes variable 'quiz_name' to quiz_take view
					url(r'^(?P<slug>[\w-]+)/$', views.QuizDetailView.as_view(), name='quiz_start_page'),

					url(r'^(?P<quiz_name>[\w-]+)/take/$',views.QuizTake.as_view(), name='quiz_question'),
]
