from django import forms
from .models import login 
from django.forms import ModelForm

class loginform(forms.Form):
	username = forms.CharField()
	password = forms.CharField(widget=forms.PasswordInput)
		
class Meta:
    model = login
    fields = '__all__'	
