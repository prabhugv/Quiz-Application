from django.shortcuts import render
from django.db import connection
from django.http import Http404
from django.http import HttpResponse
from django.contrib.auth import authenticate


# Create your views here.

from login.forms import loginform

from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response

from login.models import login

def login_view(request):
	
	if request.method == 'POST':

			form = loginform(request.POST)

			if form.is_valid():

				username = request.POST.get('username')
				password = request.POST.get('password')
				cursor = connection.cursor()
				cursor.execute("select * from auth_user where name = %s or  email = %s",[username,password])
				row = cursor.fetchone()
				if row:
					if row[0] == password:
						pass
					else:
						return render(request,'login/login.html',{'form':form,})
				else:
					return render(request,'login/login.html',{'form':form,})

				return render_to_response("login/index.html")

	else:

		form = loginform()

		return render(request,'login/login.html',{'form':form,})
		
		
def homeview(request):
	return render(request, 'login/home_page.html')		

		

